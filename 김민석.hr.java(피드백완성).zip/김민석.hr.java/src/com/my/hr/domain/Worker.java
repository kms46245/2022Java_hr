package com.my.hr.domain;

import java.time.LocalDate;

public class Worker {
	private int id;
	private String name;
	private LocalDate joinDate;
	
	public Worker(int id ,String name, LocalDate joinDate) {
		this.id = id;
		this.name = name;
		this.joinDate = joinDate;
		
	}
	
	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public LocalDate getJoinDate() {
		return joinDate;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setJoinDate(LocalDate joinDate) {
		this.joinDate = joinDate;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	@Override
	public String toString() {
		return String.format("%-2d %-6s %5s", id + 1, name, joinDate);
	}
}
