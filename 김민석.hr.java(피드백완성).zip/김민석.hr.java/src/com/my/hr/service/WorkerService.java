package com.my.hr.service;

import java.time.LocalDate;
import java.util.List;

import com.my.hr.domain.Worker;

public interface WorkerService {
	void addWorker(Worker worker);
	void delWorker(Worker worker);
	void fixWorker(int idx, String name, LocalDate joinDate);
	
	List<Worker> getWorkers();
}
