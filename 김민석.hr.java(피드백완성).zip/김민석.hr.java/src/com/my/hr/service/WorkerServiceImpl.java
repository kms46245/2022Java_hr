package com.my.hr.service;

import java.time.LocalDate;
import java.util.List;

import com.my.hr.dao.WorkerDao;
import com.my.hr.domain.Worker;

public class WorkerServiceImpl implements WorkerService{
	private WorkerDao workerDao;
	
	public WorkerServiceImpl(WorkerDao workerDao) {
		this.workerDao = workerDao;
	}
	
	@Override
	public void addWorker(Worker worker) {
		workerDao.insertWorker(worker);
	}
	
	@Override
	public void delWorker(Worker worker) {
		workerDao.deleteWorker(worker);
	}
	
	@Override
	public void fixWorker(int idx, String name, LocalDate joinDate) {
		Worker upWorker = new Worker(getWorkers().get(idx).getId()
				, name, joinDate);
		workerDao.selectWorkers().set(idx, upWorker);	
	}
	
	@Override
	public List<Worker> getWorkers(){
		List<Worker> workers = workerDao.selectWorkers();
		return workers;
	}
	
	
}
