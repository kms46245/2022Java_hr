package com.my.hr.dao;

import java.time.LocalDate;
import java.util.List;

import com.my.hr.domain.Worker;

public class WorkerDaoImpl implements WorkerDao{
	private List<Worker> workers;
	
	public WorkerDaoImpl(List<Worker> workers) {
		this.workers = workers;
	}
	
	@Override
	public void insertWorker(Worker worker) {
		workers.add(worker);
	}
	
	@Override
	public void updateWorker(Worker worker, String workerName, LocalDate worekrJoinDate) {
		workers.get(worker.getId()).setName(workerName);
		workers.get(worker.getId()).setJoinDate(worekrJoinDate);
	}
	
	@Override
	public void deleteWorker(Worker worker) {
		workers.remove(worker);
	}
	
	@Override
	public List<Worker> selectWorkers(){
		return this.workers;
	}
}
