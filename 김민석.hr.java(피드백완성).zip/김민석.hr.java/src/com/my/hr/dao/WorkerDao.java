package com.my.hr.dao;

import java.time.LocalDate;
import java.util.List;

import com.my.hr.domain.Worker;

public interface WorkerDao {
	void insertWorker(Worker worker);
	void updateWorker(Worker worker, String workerName, LocalDate workerJoinDate);
	void deleteWorker(Worker worker);
	List<Worker> selectWorkers();
	
}
